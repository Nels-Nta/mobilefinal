import * as React from 'react';
import MainContainer from './Navigation/Maincontainer';

function App() {
  return (
   <MainContainer/>
  );
}

export default  App;

