import React, { useState, useEffect } from 'react';
import MapView, { Marker } from 'react-native-maps';
import { StyleSheet, Text, View, Dimensions, Button, Alert } from 'react-native';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';

const homeLocation = { // Replace with your home coordinates
  latitude: -1.972274, 
  longitude: 30.044530,
};

const workLocation = { // Replace with your work coordinates
  latitude: -1.95544,
  longitude: 30.10422,
};

const homeRadius = 100; // In meters
const workRadius = 100;

export async function SendPushNotification(title, message) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: title,
      body: message,
      data: { data: 'goes here' },
    },
    trigger: { seconds: 10 },
  });
}

export default function App() {
   const sendNotification = (title, body) => {
    SendPushNotification(title, body); // Use SendPushNotification function
  };
  const initialRegion = {
    latitude: -1.97420,
    longitude: 30.04718,
    latitudeDelta: 0.1,
    longitudeDelta: 0.1,
  };
  const [mapRegion, setMapRegion] = useState(initialRegion);
  const [errorMsg, setErrorMsg] = useState('');
  const [locationSubscription, setLocationSubscription] = useState(null);

  useEffect(() => {
    const startWatchingLocation = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission denied');
        return;
      }

      const subscription = await Location.watchPositionAsync(
        {
          enableHighAccuracy: true,
          distanceInterval: 10, // Update location every 10 meters
        },
        (location) => {
          setMapRegion({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            latitudeDelta: 0.1,
            longitudeDelta: 0.1,
          });
          checkLocationBounds(location.coords.latitude, location.coords.longitude);
        }
      );

      setLocationSubscription(subscription);
    };

    startWatchingLocation();

    return () => {
      // Clean up the location subscription when the component unmounts
      if (locationSubscription) {
        locationSubscription.remove();
      }
    };
  }, []);

  const checkLocationBounds = (latitude, longitude) => {
    const distanceFromHome = calculateDistance(homeLocation.latitude, homeLocation.longitude, latitude, longitude);
    const distanceFromWork = calculateDistance(workLocation.latitude, workLocation.longitude, latitude, longitude);

    if (distanceFromHome <= homeRadius) {
      sendNotification('You have reached home');
    } else if (distanceFromWork <= workRadius) {
      sendNotification('You have reached work');
    } else if (calculateDistance(initialRegion.latitude, initialRegion.longitude, latitude, longitude) > 4) {
      sendNotification('Out of Range', 'You are more than 4 meters away from the initial location.');
    }
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km
    return distance * 1000; // Convert to meters
  };

  const deg2rad = (deg) => {
    return deg * (Math.PI / 180);
  };


  return (
    <View style={styles.container}>
      <MapView style={styles.map} region={mapRegion}>
        <Marker coordinate={mapRegion} title="Current Location" />
        <Marker coordinate={homeLocation} title="Home" pinColor="green" />
        <Marker coordinate={workLocation} title="Work" pinColor="blue" />
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});