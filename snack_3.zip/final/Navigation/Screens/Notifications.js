import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Button } from 'react-native';
import * as Notifications from 'expo-notifications';

export default function App() {
  const [expoPushToken, setExpoPushToken] = useState('');

  useEffect(() => {
    registerForPushNotificationsAsync().then(token => setExpoPushToken(token));
    
    const notificationListener = Notifications.addNotificationReceivedListener(handleNotification);
    return () => {
      Notifications.removeNotificationSubscription(notificationListener);
    };
  }, []);

  const handleNotification = notification => {
    console.log(notification);
    // Handle foreground notifications here
  };

  async function registerForPushNotificationsAsync() {
    let token;
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      alert('Failed to get push token for push notification!');
      return;
    }
    token = (await Notifications.getExpoPushTokenAsync()).data;
    return token;
  }

  const sendPushNotification = async () => {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Hello!',
        body: 'This is a test notification',
      },
      trigger: { seconds: 1 },
    });
  };

  return (
    <View style={styles.container}>
      <Button title="Send Notification" onPress={sendPushNotification} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff'
  }});