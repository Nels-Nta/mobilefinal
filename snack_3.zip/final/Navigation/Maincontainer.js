import * as React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList, DrawerItem } from '@react-navigation/drawer';
import Ionicons from 'react-native-vector-icons/Ionicons';

import GpsScreen from './Screens/Question3';

import Light from './Screens/LightSensor'
import Notification from './Screens/Notifications'

import Motion from './Screens/Q2'

const GpsName = 'Gps'

const Lights = 'Light'
const Notifications='Notification'

const Security = 'Motion'

const Drawer = createDrawerNavigator();

export default function MainContainer() {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        initialRouteName={GpsName}
        drawerContent={(props) => <CustomDrawerContent {...props} />}>
        <Drawer.Screen name={GpsName} component={GpsScreen} />
        
        <Drawer.Screen name={Lights} component={Light} />
        <Drawer.Screen name={Notifications} component={Notification} />
       
        <Drawer.Screen name={Security} component={Motion} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props}>
      <DrawerItemList {...props} />
      <DrawerItem
        label="Close drawer"
        onPress={() => props.navigation.closeDrawer()}
      />
    </DrawerContentScrollView>
  );
}
